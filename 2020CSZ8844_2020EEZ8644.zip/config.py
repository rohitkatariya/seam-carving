import datetime
data_dir = 'Data/'
input_dir = 'Data/input/'
output_dir = data_dir+"output/"
date_str = datetime.datetime.now().strftime("%Y%m%d_%H%M")